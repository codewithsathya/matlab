function y = DTFT(x, w, n)
    y = zeros(length(w));
    for i = 1 : length(w)
        for k = 1 : length(x)
              y(i) = y(i) + x(k) .* exp(-1i .* w(i).*(n(k)));
        end
    end
end